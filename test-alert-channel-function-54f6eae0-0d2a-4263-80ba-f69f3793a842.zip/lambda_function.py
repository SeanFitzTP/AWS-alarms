import json, sys, os
import requests

# Environment Variable
WEBHOOK_URL=os.environ['SLACK_WEBHOOK_URL']
DASHBOARD=os.environ['ERROR_DASHBOARD']
DASHBOARD2=os.environ['ERROR_DASHBOARD2']
aws_dashboard_url = "https://us-west-2.console.aws.amazon.com/cloudwatch/home?region=us-west-2#dashboards:name=payment-serviceV2"

def send_alert_slack(message):
    try:
        r = requests.post(WEBHOOK_URL, json=message)
        r.raise_for_status()
    except requests.exceptions.HTTPError as errh:
        raise Exception(errh)
    except requests.exceptions.ConnectionError as errc:
        raise Exception(errc)
    except requests.exceptions.Timeout as errt:
        raise Exception(errt)
    except requests.exceptions.RequestException as err:
        raise Exception(err)
    # print(requests)
def prepare_message(record):
    subject = record['Sns']['Subject']
    message = json.loads(record['Sns']['Message'])
    link = f"Here's the link to the AWS dashboard: {DASHBOARD}"
    link2 = f"Here's the link to the AWS dashboard: {DASHBOARD2}"
    contains_hybrid = "Hybrid" in message['AlarmName']
    if contains_hybrid:
     body = {
        'text': subject,
        'attachments': [{
            'text': message['AlarmName'],
            'text': link2,
            'fields': [{
              'title': 'Reason',
              'value': message['NewStateReason'],
              'short': True,
            }],
        }],
    }
    else: 
     body = {
        'text': subject,
        'attachments': [{
            'text': message['AlarmName'],
            'text': link,
            'fields': [{
              'title': 'Reason',
              'value': message['NewStateReason'],
              'short': True,
            }],
        }],
    }
    return send_alert_slack(body)
def lambda_handler(event, context):
    try:
        print("event received", json.dumps(event))
        for single_event in event['Records']:
            prepare_message(single_event)
    except Exception as e:
        raise Exception(e)
    #looping through events array of objects